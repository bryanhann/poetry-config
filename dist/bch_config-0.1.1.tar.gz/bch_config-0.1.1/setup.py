# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['bch_config']

package_data = \
{'': ['*']}

install_requires = \
['bch_inject @ git+https://github.com/bryanhann/poetry.bch_inject@0.1.2']

entry_points = \
{'console_scripts': ['bch-config = bch_config.console:run',
                     'bch-config-ini-dump = bch_config.console:dump_ini',
                     'bch-config-usage = bch_config.console:usage']}

setup_kwargs = {
    'name': 'bch-config',
    'version': '0.1.1',
    'description': '',
    'long_description': None,
    'author': 'Bryan Hann',
    'author_email': 'nobody@nowhere',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
