#!/usr/bin/env python3

from pathlib import Path

CONFIG=Path.home()/'.config'
INI_FILENAME='fig.ini'
